import axios from "axios"
export default axios.create({
    baseURL:"http://148.66.135.245:8001/"
  
})